Mod has been tested with Stardew 1.3.28, SMAPI 2.7 & Content Patcher 1.4 
(you could probably use Stardew 1.3.28+ SMAPI 2.7+/Content Patcher 1.4+)


----------------CHANGELOG------------------
view the Changelog.md file (open using Notepad or Notepad++)
-------------------------------------------------------
INSTALLATION

1. Install Latest Version of SMAPI
2. Install Latest Version of Content Patcher
3. Download this mod and extract/unzip into "Stardew Valley/Mods"

CONFIG.JSON DETAILS

(By Default, EVERYTHING IS "Enabled".)
To enable a feature, type in "enabled", To disable something, type in "disabled" instead in the 'config.json'

Features you can enable/disable in the config.json file (pretty much everything)

Valley Life Standard Farm: the new farm map
Valley Life Starting Farmhouse with Kitchen: a kitchen for your first un-upgraded farmhouse
Valley Life Large Farmhouse with Attic: an attic for your large farmhouse(2nd upgrade($50k and 150 hardwood))
Valley Life Greenhouse: the new greenhouse
Valley Life Cellar: the new cellar for your maxed-out farmhouse($100k upgrade)

If you need help, You can join the SDV discord in #modding to report your issues

Some planned updates:
-----------------------------------









