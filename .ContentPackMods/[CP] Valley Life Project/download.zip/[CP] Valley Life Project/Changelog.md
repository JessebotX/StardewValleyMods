# RELEASE NOTES [(Project Valley Life)](https://www.nexusmods.com/stardewvalley/mods/2909)

### v1.1.2 (Nov 17, 2018)
- Fixes farmhouse stairs being blocked?????
- You now must run the game once first for the ```config.json``` file to generate
