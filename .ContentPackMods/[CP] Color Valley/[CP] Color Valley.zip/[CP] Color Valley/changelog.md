# RELEASE NOTES 
(Color Valley: [(nexus)](https://www.nexusmods.com/stardewvalley/mods/3294))

## v1.0.1 (5/08/2019)
- Updated ```ConfigSchema``` for Content Patcher 1.7
- Added ```MinimumApiVersion``` and ContentPackFor's ```MinimumVersion``` for Content Patcher
  - Requires SMAPI 2.11.0+ and Content Patcher 1.7.0+

## v1.0 (4/30/2019)
- Initial Release
