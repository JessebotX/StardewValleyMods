# RELEASE NOTES 
[(Winter Woods - Secret Woods Expansion)](https://www.nexusmods.com/stardewvalley/mods/3211)

## 1.0.2 (1/6/2019)
- Fixed gingerbread house teleporter. You can now access the winter woods hot spring at winter

## 1.0.1 (1/4/2019)
- Fixed duplicate files download

## 1.0 (1/3/2019)
- Initial Release