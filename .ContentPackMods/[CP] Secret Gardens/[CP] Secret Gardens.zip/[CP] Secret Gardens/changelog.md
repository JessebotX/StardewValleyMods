# RELEASE NOTES [(source)](https://www.nexusmods.com/stardewvalley/mods/3067)

## v2.0.1 (Dec 9, 2018)
- Mod will disable itself if you have the mod ["Tunnel System"](https://www.nexusmods.com/stardewvalley/mods/3082) installed.
  - The secret gardens has been implemented into Tunnel System.
  - Now requires Stardew 1.3.32+, SMAPI 2.9+ and Content Patcher 1.6+
- ModDrop update keys

## v2.0 (Nov 25, 2018)
- Added Swimming Lake
- Added a plain version of the gardens without the fountains and stuff around the lake (disabled by default)
	- See config_instructions.txt in the folder
- Removed the ugly stuff sitting on the lake

## v1.0 (Nov 17, 2018)
- Initial Release :D
- A new greenhouse replacement