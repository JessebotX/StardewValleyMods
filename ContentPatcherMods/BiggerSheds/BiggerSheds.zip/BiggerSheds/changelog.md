# RELEASE NOTES
### [(Bigger Sheds Nexus download)]

## v2.0.2 (Dec 2, 2018)
- Fixed typo in the "ConfigSchema" field

## v2.0.1 (Dec 2, 2018)
- Fixed typo that caused an error for the ```wood``` shed
- Removed config.json so that your settings don't get reset every time (To Generate a config.json, run the game once via SMAPI with this mod installed)
- Mod now open source. [(Click here)](https://github.com/JessebotX/StardewMods/tree/master/ContentPatcherMods/BiggerSheds)

## ???
See [Nexus Changelog](https://www.nexusmods.com/stardewvalley/mods/2816?tab=description) for previous release notes