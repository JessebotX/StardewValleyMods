Changelog

- v1.2 (Farmhouse Expansions)
	- Farmhouse Upgrade 1 now has a 30x15 plot
	- Farmhouse Upgrade 2 now has a 30x30 plot
- v1.1 (Spouse Room Update)
	- Added Spouse Rooms
	- Main Farmhouse now has farmland
- v1.0 (Initial Release)
	- Initial Release
	- Farm in cabins