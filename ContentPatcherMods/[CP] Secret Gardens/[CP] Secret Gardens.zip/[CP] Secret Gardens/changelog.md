# RELEASE NOTES [(source)](https://www.nexusmods.com/stardewvalley/mods/3067)

### v2.0 (Nov 25, 2018)
- Added Swimming Lake
- Added a plain version of the gardens without the fountains and stuff around the lake (disabled by default)
	- See config_instructions.txt in the folder
- Removed the ugly stuff sitting on the lake

### v1.0 (Nov 17, 2018)
- Initial Release :D
- A new greenhouse replacement