﻿using System;
using Microsoft.Xna.Framework;
using StardewModdingAPI;
using StardewModdingAPI.Events;
using StardewModdingAPI.Utilities;
using StardewValley;


namespace BiggerRiverlandsFarm
{
    class ModConfig
    {
        public int MapType { get; set; } = 0;
    }
}
