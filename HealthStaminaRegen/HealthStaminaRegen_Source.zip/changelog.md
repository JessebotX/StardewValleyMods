# RELEASE NOTES
[(Health and Stamina Regeneration)](https://www.nexusmods.com/stardewvalley/mods/3207)

## v1.0.2 (Feb 11, 2019)
- Possibly fixes the ```StaminaRegenRate``` field

## v1.0.1 (Jan 7, 2019)
- More customizable with ```StaminaRegenRate``` in the config.json
  - accepts decimal values (up to 3 decimal places (eg. ```1.555```))

## v1.0 (Jan 6, 2019)
- Initial Release :D
