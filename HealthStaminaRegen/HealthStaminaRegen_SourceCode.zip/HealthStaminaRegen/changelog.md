# RELEASE NOTES [(source)](https://www.nexusmods.com/stardewvalley/mods/3207)

## v1.0.1 (Jan 7, 2018)
- More customizable with ```StaminaRegenRate``` in the config.json
  - accepts decimal values (up to 3 decimal places (eg. ```1.555```))

## v1.0 (Jan 6, 2018)
- Initial Release :D