# RELEASE NOTES [(source)](https://www.nexusmods.com/stardewvalley/mods/3207)

## v1.0 (Jan 2, 2018)
- Initial Release :D