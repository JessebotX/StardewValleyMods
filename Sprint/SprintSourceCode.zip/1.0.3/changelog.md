# RELEASE NOTES 
[(Sprint Sprint Sprint)](https://www.nexusmods.com/stardewvalley/mods/3294)

## v1.0.2 (01/27/2019)
- Fixed bug where stamina drains even if you're not sprinting

## v1.0.1 (01/27/2019)
- Fixed shift button
  - Previously, you couldn't use the shift button to quickly buy, deposit or withdraw items
  - Sprinting may look a bit weird if you have LeftShift as your sprint key

## v1.0 (01/26/2019)
- Initial Release
