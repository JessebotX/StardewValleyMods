# RELEASE NOTES 
[(Sprint Sprint Sprint)]()

## v1.0
- Initial Release
- More Configurable
  - ```StaminaDrain```: enables Stamina draining when sprinting (default ```true```)
  - ```StaminaDrainPerSecond```: how much stamina is loss per second (default ```0.5f```)